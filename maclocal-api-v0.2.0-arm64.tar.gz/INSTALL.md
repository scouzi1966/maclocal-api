# MacLocalAPI v0.2.0 - Installation Guide

## Quick Start

1. **Extract the binary**:
   ```bash
   chmod +x MacLocalAPI
   ```

2. **Run the server**:
   ```bash
   ./MacLocalAPI
   ```

3. **Test streaming**:
   ```bash
   ./test-streaming.sh
   ```

4. **Test metrics**:
   ```bash
   ./test-metrics.sh
   ```

## Requirements

- **macOS 26+** with Apple Intelligence enabled
- **Apple Silicon** (M1, M2, M3, M4 chips)
- **System Settings** → Apple Intelligence & Siri → Enable Apple Intelligence

## Server Options

```bash
# Default port 8080
./MacLocalAPI

# Custom port
./MacLocalAPI --port 9999

# Verbose logging
./MacLocalAPI --verbose
```

## API Endpoints

- **Chat Completions**: `POST /v1/chat/completions`
- **Models**: `GET /v1/models`
- **Health**: `GET /health`

## Compatible with

- OpenAI SDK
- Open WebUI
- Cursor IDE
- Any OpenAI-compatible client

## Support

For issues and updates: https://github.com/scouzi1966/maclocal-api